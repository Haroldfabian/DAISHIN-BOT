const toinmenu = (prefix, pushname) => {
    return `◪ *Comandos de Felixcrack*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.toinmenu = toinmenu