const version = (prefix, pushname) => {
    return `
*FX-BOT-73 🤖*

*Actualizado:* 19 De Junio
*Versión actual:* 73
*Ofrecida por:* Felixcrack

Para conocer la ultima versión de FX-BOT-73 entra al siguiente blog



by Felixcrack
`

}

exports.version = version
