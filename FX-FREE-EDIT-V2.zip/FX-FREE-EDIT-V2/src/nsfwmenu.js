const nsfwmenu = (prefix, pushname) => {
    return `*Comandos para ver pornito 🔞*
*NSFW ✅*

- ${prefix}pussy
- ${prefix}pussyimage
- ${prefix}solog
- ${prefix}yuri
- ${prefix}anal
- ${prefix}pwankg
- ${prefix}eron
- ${prefix}ero
- ${prefix}erok
- ${prefix}hentai

_El bot nesecita admin y tener activado los NSFW_\n _Digita_\n ${prefix}*nsfw 1*

Algunas funciones fueron eliminas por errores en el servidor de la India

By Felixcrack`

}

exports.nsfwmenu = nsfwmenu
