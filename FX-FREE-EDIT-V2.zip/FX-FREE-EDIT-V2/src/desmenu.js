const desmenu = (prefix, pushname) => {
    return `
*Comandos De Descargas ✅*
 
- ${prefix}play
  Coloca El Nombre De La Cancion
- ${prefix}ytmp3
  Coloca El Link Del Video YT
- ${prefix}ytmp4
  Coloca El Link Del Video YT
     
By Felixcrack`

}

exports.desmenu = desmenu
